<template>
    <div>
        <h3>我是Navbar</h3>
        <button @click="emitEvent">点击显示sidebar</button>
        <slot></slot>
    </div>
</template>

<script>
    export default {
        methods:{
            emitEvent(){
                this.$emit("myevent");
            }
        }
    }
</script>