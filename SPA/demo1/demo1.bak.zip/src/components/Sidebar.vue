<template>
    <div>
        <h3>我是Sidebar</h3>
        <ul>
            <li>111111</li>
            <li  v-show="pro">22222</li>
            <li>33333</li>
        </ul>
    </div>
</template>

<script>
    export default{
        props:["pro"]
    }
</script>