<template>
    <div>
        <ul>
            <!-- <li>你好李焕英</li>
            <li>唐人街探案三</li>
            <li>新警察故事</li>
            <li>宝贝计划</li> -->
            <li v-for="(data) in dataList" :key="data.id" @click="handleClick(data.id)">{{data.title}}</li>
        </ul>
    </div>
</template>

<script>
export default {
    data(){
        return{
            // dataList:['你好李焕英','唐人街探案三','新警察故事','宝贝计划','武林外传'],
            dataList:[
                {
                    id:111,
                    title:'你好李焕英'
                },
                {
                    id:222,
                    title:'唐人街探案三'
                },
                {
                    id:333,
                    title:'新警察故事'
                },
                {
                    id:444,
                    title:'武林外传'
                },
            ]
        }
    },
    methods:{
        handleClick(id){
            // console.log(id);

            // 1-路径
            this.$router.push(`/detail/${id}`);         //编程式导航

            // 2-路由名字
            // this.$router.push({
            //     name:'kerwinDetail',
            //     params:{
            //         filmId:id
            //     }
            // })


            // 3-query方式跳转详情
            // this.$router.push(`/detail?filmId=${id}`)
        }
    }
}
</script>

<style scoped>
    ul{
        list-style: none;
        margin: 0;
        padding: 0;
    }
    ul>li{
        /* width: inherit; */
        height: 80px;
        border: 1px solid #000;
        cursor: pointer;
        border-radius: 5px;
        margin: 10px 0;
        text-align: center;
        line-height: 80px;
        transition: font-size .2s;
    }
    ul>li:hover{
        background: rgb(63, 101, 224);
        color: white;
        font-size: 30px;
    }
</style>