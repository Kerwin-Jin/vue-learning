<template>
  <div>
    <div id="sliper">
      <h1>大轮播</h1>
    </div>
    <ul>
        <router-link to="/film/nowplaying" tag="li" active-class="kerwinactive">正在热映</router-link>
        <router-link to="/film/comingsoon" tag="li" active-class="kerwinactive">即将上映</router-link>
    </ul>
    <router-view></router-view>
  </div>
</template>


<style scoped>
    #sliper {
        width: 1200px;
        height: 20vh;
        border: 1px solid #000;
        margin: 10px auto;
    }
    ul{
        list-style: none;
        margin: 0;
        padding: 0;
        display: flex;
    }
    ul li{
        height: 40px;
        flex: 1;
        text-align: center;
    }
    .kerwinactive{
        background: #f40;
    }
</style>