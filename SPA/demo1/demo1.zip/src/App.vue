<template>
  <div>
    <h1>{{name}}</h1>
    <button @click="handleClick">{{text}}</button>
    <ul v-if="isShow">
      <li v-for="(book,index) in books" :key="book">{{index+1}}-----{{book}}</li>
    </ul>
    <h1>TODOLIST</h1>
    <input type="text" v-model="info" @keyup.enter="addTodo" placeholder="Enter添加">
    <div v-show="list.length == 0?false:true">
      <ul class="listshow">
        <li v-for="(item,index) in list" :key="item">{{item}}<a href="javascript:;" @click="delItem(index)">删除</a></li>
      </ul>
    </div>

    <h1>抽屉-父子组件传值</h1>
    <navbar @myevent="handleEvent">
      <button @click="sideShow = !sideShow">slot-click</button>
    </navbar>
    <sidebar v-show="sideShow" :pro="false"></sidebar>
  </div>
</template>

<script>
import navbar from "./components/Navbar.vue";
import sidebar from "./components/Sidebar";
import Vue from "vue"

Vue.component("navbar",navbar);

export default {

  components:{
    sidebar
  },
  data(){
    return {
      text:"点击显示",
      isShow:false,
      sideShow:false,
      name:"Kerwin Dream",
      books:["人类简史","人性的弱点","自卑与超越"],
      info:"",
      list:[]
    }
  },
  methods:{
    handleClick(){
      this.isShow = !this.isShow;
      if(this.text == '点击显示'){
        this.text = '点击隐藏';
      }else{
        this.text = '点击显示';
      }
    },
    addTodo(){
      this.list.push(this.info);
      this.info = "";
    },
    delItem(index){
      this.list.splice(index,1);
    },
    handleEvent(){
      this.sideShow = !this.sideShow;
    }
  }
}
</script>

<style scoped>
  ul{
    margin:0;
    padding:0;
    list-style:none;
  }
  li:hover{
    background:#ccbf9c;
  }
  .listshow li{
    cursor: pointer;
    width: 300px;
    display: flex;
    justify-content: space-between;
  }
</style>