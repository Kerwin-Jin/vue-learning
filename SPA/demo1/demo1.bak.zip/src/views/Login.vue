<template>
    <div>
        <h1>登录页面</h1>
        用户名：<input type="text">
        密码：<input type="password">
        <button>登录</button>
    </div>
</template>