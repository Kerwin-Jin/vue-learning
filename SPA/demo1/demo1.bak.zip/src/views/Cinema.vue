<template>
    <div>
        Cinema
    </div>
</template>