<template>
    <nav>
        <ul>
            <router-link to="/film" tag="li" active-class="kerwinactive">电影</router-link>
            <router-link to="/cinema" tag="li" active-class="kerwinactive">影院</router-link>
            <router-link to="/center" tag="li" active-class="kerwinactive">我的</router-link>
        </ul>
    </nav>
</template>

<style scoped>
    nav ul{
        display: flex;
        list-style: none;
        margin: 0;
        justify-content: space-around;
        padding: 0;
    }
    nav ul li{
        border: 1px solid #f40;
        flex: 1;
        height: 40px;
        text-align: center;
        line-height: 40px;
    }
    nav ul li:hover{
        background: coral;
        color: white;
    }
    .kerwinactive{
        background: red;
        color: white;
    }
</style>